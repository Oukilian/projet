<div id="textzone">
<form method="post" action="corps/env_mess.php">

<input type="text" name="title" value="title" /><br /><br />
<textarea name="message" id="message"  rows="10" cols="40"/></textarea><br/>
	<br/><input type="submit" name="ok" value="envoyer" />

</form>
</div>
	
