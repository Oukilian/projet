<?php
	include('../start.php');
	
	$req = $bdd->prepare("INSERT INTO msg(pseudo, titre, article) VALUES(?, ?, ?)");
	
	$nom = $_SESSION['name'];
	$title = $_POST['title'];
	$article = $_POST['message'];
	$res = $req->execute(array($nom ,$title, $article));
	header('Location:http://localhost/css/index.php');
?>
